package bootcamp.pretest.qsthree;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class StoreAvailabilityService {
	
	private List<Calendar> calendars = new ArrayList<Calendar>();
	
//	{
//		calendars.add(Calendar("STORE001", "ALL", "13:30"));
//		
//		Calendar("STORE002", "SUNDAY",  "13:30") 
//		Calendar("STORE003", "MONDAY", "13:30")
//	}
	public StoreAvailabilityService() {
	}
	

//	public int checkAvailability(String productId) {
//
//		
//
//	}

}
